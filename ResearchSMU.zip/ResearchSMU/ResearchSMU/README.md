# ResearchSMU
CSE 3330/3345 Spring 2015 Project

https://docs.google.com/spreadsheets/d/1WG0TvwnXxUHx-W4Q7MVq2STe73t1AZWCVLOovyfSULI/edit#gid=519634633

AWS server 
http://52.11.153.243/